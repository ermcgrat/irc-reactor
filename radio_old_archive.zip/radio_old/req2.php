<html>
<head>
</head>
<body>
<?

// Set the IP for your bot, ou can use * as wildcard
// Remember to set this correctly, or requesting wont work
// Using * will allow exploiting this script, so I suggest you setting the IP of your bot

$ip = "*";

$sam["host"] = "173.50.167.207"; //The IP address of the machine SAM is running on (DO NOT use a local IP address like 127.0.0.1 or 192.x.x.x)
$sam["port"] = "1221";      //The port SAM handles HTTP requests on. Usually 1221.

DEFINE('USER_IP', $_SERVER['REMOTE_ADDR']);
// DEFINE('USER_HOSTNAME', gethostbyaddr($_SERVER['REMOTE_ADDR']));

function Def(&$val, $def = '')
{
 if(empty($val))
   $val = $def;
   
 return $val;
}

function DoError($code)  
{
 global $samhost, $samport, $errno, $errstr;
 
 switch ($code)
 {
  case 800 : $message = "SAM host must be specified"; break;
  case 801 : $message = "SAM host can not be 127.0.0.1 or localhost"; break;
  case 802 : $message = "Song ID must be valid";  break;
  case 803 : $message = "Unable to connect to $samhost:$samport. Station might be offline.<br>The error returned was $errstr ($errno).";  break;
  case 804 : $message = "Invalid data returned!";  break;
 }
 echo "<i>$message</i></body></html>";
 exit;
}

$can_load = FALSE;

$ip = str_replace(".", "\\.", $ip);
$ip = str_replace("*", "[0-9]*", $ip);
$ip = str_replace("?", "[0-9]?", $ip);
if (ereg($ip, USER_IP)) $can_load = TRUE;

if ($can_load) {
    
    require_once("rdio/common/xml.php");
		if (!empty($_GET['songid'])) $songid = $_GET['songid'];
		if (!empty($_POST['songid'])) $songid = $_POST['songid'];

		Def($samhost,$sam["host"]);
		Def($samport,$sam["port"]);
		Def($dedicated,false);
 
		if(empty($samhost)) DoError(800);
		$host = $_SERVER['REMOTE_ADDR'];

		if($songid == -1) DoError(802);

		$request = "GET /req/?songid=".$songid."&host=".$_GET['host']." HTTP\1.0\r\n\r\n";
		$xmldata = "";
		$fd = @fsockopen($samhost,$samport, $errno, $errstr, 30);	
    
    // send the request to the dj program
		if(!empty($fd))
			{		
      fputs ($fd, $request);
      
			$line="";
			while(!($line=="\r\n"))
			{ $line=fgets($fd,128); }	// strip out the header
			while ($buffer = fgets($fd, 4096))
			{  $xmldata  .= $buffer; }
			fclose($fd);
		}
		else DoError(803);

		if(empty($xmldata)) DoError(804);
  
		//#################################
		//      Initialize data
		//#################################
		$tree = XML2Array($xmldata);
		$request = Keys2Lower($tree["REQUEST"]);
 
		$code    = $request["status"]["code"];
		$message = $request["status"]["message"];
		$requestid = $request["status"]["requestid"];
		if(empty($code)) DoError(804);
 
		if($code==200)
		echo "<b>The request was succesfully sent to the Radio Station</b>"; else
		echo "<i>$message</i>";
} else echo "<i>Check the configured IP address</i>";
?>
</body>
</html>

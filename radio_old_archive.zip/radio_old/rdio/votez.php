<? require("header.php"); ?>

<?php

    $songid = intval( $_GET['id'] );
    if ( $songid <= 0 ) {
        die ('Please specify a valid Song ID.');
    }

    $link = mysql_connect( "192.168.1.105", "ermcgrat1","EricIzThatWook");
     if ( $link ) {
        $db_select = mysql_select_db( "ermcgrat1", $link);
        if ( $db_select ) {

        } else {
          die("Could not select database.");
        }
     } else {
      die("Could not connect to database.");
     }

     $result = mysql_query( "Select id, artist, title, album From songlist Where ID = $songid");
     $row = mysql_fetch_array( $result );
     $songid = $row['id'];
     if ( $songid > 0 ) {
         $song_desc = $row['title'] . " by " . $row['artist'] . " (" . $row['album'] . ")";
     } else {
         mysql_close($link);
         die ('Please specify a valid Song ID.');
     }
?>

<table border="0" width="98%" cellspacing="0" cellpadding="4">
  <tr bgcolor="#002E5B">
    <td colspan="3" nowrap align="left">
      <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFFFF">Voting History for <?php echo $song_desc; ?></font></b>
    </td>
  </tr>
  <tr bgcolor="#dadada">
    <td>Host Mask</td>
    <td>Rating</td>
    <td>Timestamp</td>
  </tr>

  <?php

    $result = mysql_query( "Select score, t_stamp, host From votez Where songID = $songid");

    while ( $row = mysql_fetch_array( $result ) ) {


        $score = $row['score'];
        $t_stamp = $row['t_stamp'];
        $host = $row['host'];
        if ( $color == "#F6F6F6") {
            $color = "#dadada";
        } else {
            $color = "#F6F6F6";
        }

        echo '<tr bgcolor="' . $color . '">';
        echo '<td>' . $host . '</td>';
        echo '<td>';
        for ( $x = 1; $x <= $score; $x++ ) {
                echo '<img style="border:none;" src="images/star.png">';
        }
        echo '</td>';
        echo '<td>' . $t_stamp . '</td>';

        echo '</tr>';

    }
    mysql_close($link);

  ?>


</table>
<br />
<a href="#" onClick="history.back(); return false;">Back to Playlist & Requests</a>
</body>
</html>

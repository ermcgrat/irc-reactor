<table border="0" cellspacing="0" cellpadding="2" bgcolor="#EEEEEE">
  <tr>
    <td nowrap colspan="2" bgcolor="#C0C0C0" align="center"><b>Navigation</b></td>
  </tr>
  <tr>
    <td nowrap align="center"><img border="0" src="images/play.gif"></td>
    <td nowrap><a href="playing.php">Now playing</a></td>
  </tr>
  <tr>
    <td nowrap align="center"><img border="0" src="images/tb-file-list.gif"></td>
    <td nowrap><a href="playlist.php?limit=25">Playlist &amp; Requests</a></td>
  </tr>
<!--
  <tr>
    <td nowrap align="center"><img border="0" src="images/email.gif"></td>
    <td nowrap><a href="mailto:<? echo $email; ?>">Email us!</a></td>
  </tr>
-->
</table>

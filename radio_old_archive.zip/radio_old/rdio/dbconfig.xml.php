<?/* 
<CONFIG application="SAM" version="4.3.2">
	<Database>
		<Driver>MYSQL</Driver>
		<Host>192.168.1.105</Host>
		<Port>3306</Port>
		<Database>ermcgrat1</Database>
		<Username>ermcgrat1</Username>
		<Password>EricIzThatWook</Password>
	</Database>
</CONFIG>

 */?>
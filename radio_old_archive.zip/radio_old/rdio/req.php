<?
 require_once("config.php"); 
 require_once("common/xml.php");
 
 if(empty($requestid))      // looks like this is empty when clicking on request button
   require_once("req/req.php");
 else                       // but after hitting 'dedicate it' this becomes set
   require_once("req/req.dedication.php");
?>
function request(songid)
{
 reqwin = window.open("req.php?songid="+songid, "_AR_request", "location=no,status=no,menubar=no,scrollbars=no,resizeable=yes,height=420,width=668");
}
